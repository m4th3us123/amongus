class Player {
  constructor (){}


getCount(){
  // leia os dados e armazene o valor de playerCount


  
}

updateCount (count){
  // atualize o playerCount
  
}
}
